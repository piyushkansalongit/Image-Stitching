For perspective transformations, go to perspective folder.

Put your data into a folder and put that folder into "Data" folder.

Run python panorama.py and find your results in visuals folder.